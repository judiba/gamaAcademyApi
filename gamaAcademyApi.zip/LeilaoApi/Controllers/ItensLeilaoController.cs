﻿using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using LeilaoApi.Models;
using Microsoft.AspNetCore.Authorization;
using LeilaoApi.Repository;
using System;

namespace LeilaoApi.Controllers
{
    [Authorize]
    [Route("api/[controller]")]
    [ApiController]
    public class ItensLeilaoController : ControllerBase
    {
        private readonly IItensLeilaoRepository _itensRepository;

        public ItensLeilaoController(IItensLeilaoRepository itensRepository)
        {
            _itensRepository = itensRepository;
        }


        // GET: api/ItensLeilao
        [HttpGet]
        public async Task<ActionResult> GetItensLeilao()
        {
            try
            {
                var items = await _itensRepository.GetItensLeilao();
                if (items == null)
                {
                    return NotFound();
                }

                return Ok(items);
            }
            catch (Exception)
            {
                return BadRequest();
            }
        }

    }
}
